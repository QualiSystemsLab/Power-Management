# TODO Move to Async call and user 'Allow Unreserved' tag for Shutdown and Power off commands

name = "cloudshell-power-lib"