# CloudShell-power-lib

CloudShell power management common support library