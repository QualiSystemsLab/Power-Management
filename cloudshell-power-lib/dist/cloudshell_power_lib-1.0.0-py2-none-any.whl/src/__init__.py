# TODO Move to Async call and user 'Allow Unreserved' tag for Shutdown and Power off commands

# TODO rename to cloudshell-power-lib
name = "cloudshell-power-lib"