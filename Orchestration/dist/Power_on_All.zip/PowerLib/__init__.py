# TODO Make Setup & Teardown NOT add the power service, but operate independently

# TODO Move 'Power on All' and 'Power Off All' to an Orchestration Script
# TODO 4 Scripts:
# PowerSetup
# PowerTeardown
# Power on Reservation
# Power off Reservation

# TODO Move to Async call and user 'Allow Unreserved' tag for Shutdown and Power off commands

